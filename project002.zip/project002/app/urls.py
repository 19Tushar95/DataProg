# -*- encoding: utf-8 -*-
"""
License: MIT
Copyright (c) 2019 - present AppSeed.us
"""

from typing import Any
from django.urls import path, re_path
from app import views

urlpatterns = [
    re_path(r'^.*\.html', views.pages, name='pages'),

    # The home page
    path('', views.index, name='home'),
    
    # path('newEntry/', views.newEntry),
    path('viewNewEntryList/',views.viewNewList),
    path('weatherHistory/',views.weatherHistory),
    path('weatherHistoryList/',views.weatherHistoryList),
    path('weatherWithCondition/',views.weatherHistoryWithCondition),
    path('weatherById/',views.weatherHistoryById)

    

    
       
]
