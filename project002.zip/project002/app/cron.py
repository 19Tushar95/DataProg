from asyncio.log import logger
import logging

logger =logging.getLogger(__name__)

def hello():
    logger.info("=============in cron job")